<footer class="container-fluid d-flex flex-wrap justify-content-between align-items-center py-3 text-light  border-top bg-dark">
    <div class="d-flex align-items-center">
    	<span class="text-light">&copy;{{date('Y')}} All rights reserved 
			Design by Jeytech Engineering Solutions
		</span>
    </div>

    <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
    <i class="fa-brands fa-facebook fa-fw"></i>  
    <i class="fa-brands fa-twitter fa-fw"></i> 
    <i class="fa-brands fa-instagram fa-fw"></i>
    <i class="fa-brands fa-whatsapp fa-fw"></i>
    </ul>
</footer>
<script src="{{asset('storage/js/button.js')}}"></script>

</body>
</html>