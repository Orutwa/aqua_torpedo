<?php echo e(View::make('header',['title'=>'Dashboard'])); ?>

    <div class="container-fluid" style="min-height:600px" id="accordionFlushExample">
        <link rel="stylesheet" href="<?php echo e(asset('storage/css/pie.css')); ?>"> 
        <div class="row">
            <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href=""data-bs-toggle="collapse" data-bs-target="#dashboard" aria-expanded="true" aria-controls="dashboard">
                            <i class="fa-solid fa-gauge"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href=""data-bs-toggle="collapse" data-bs-target="#assets" aria-expanded="true" aria-controls="assets">
                                <i class="fa-brands fa-buffer"></i>
                                Assets
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="fa-brands fa-bandcamp"></i>
                                Models
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" aria-current="page" href=""data-bs-toggle="collapse" data-bs-target="#brands" aria-expanded="true" aria-controls="brands">
                                <i class="fa-brands fa-bitbucket"></i>
                                Brands
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="" data-bs-toggle="collapse" data-bs-target="#clients" aria-expanded="true" aria-controls="clients">
                                <i class="fa fa-users"></i>
                                Clients
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                            <i class="fa-solid fa-code-branch"></i>
                                Integrations
                            </a>
                        </li>
                    </ul>

                    <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted">
                    <span>Saved reports</span>
                    <a class="link-secondary" href="#" aria-label="Add a new report">
                        <span data-feather="plus-circle"></span>
                    </a>
                    </h6>
                    <ul class="nav flex-column mb-2">
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                            <span data-feather="file-text"></span>
                                Current month
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                            <span data-feather="file-text"></span>
                                Last quarter
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                            <span data-feather="file-text"></span>
                                Social engagement
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">
                            <span data-feather="file-text"></span>
                                Year-end sale
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <div class="collapsed navbar-toggler" data-bs-toggle="collapse" data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fa-solid fa-bars" ></i>
                    </div>
                    <h1 class="h2">Dashboard</h1>
                    <div class="text-success" type='button' data-bs-toggle="collapse" data-bs-target="#messages" aria-expanded="true" aria-controls="messages">
                        <i class="fa fa-message fa-2x"></i><span class="badge bg-danger"><?php echo e($messages->where('status',0)->count()); ?></span>
                    </div>
                </div>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#type"><i class="fa fa-plus"></i> Type</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#model"><i class="fa fa-plus" ></i> Model</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#brand"><i class="fa fa-plus"></i> Brand</button>
                    </div>
                </div>
                <div id="dashboard" class="accordion-collapse collapse show" aria-labelledby="dashboard" data-bs-parent="#accordionFlushExample" style="text-align:center ;">
                    <h2>Summary</h2>
                    <div class="row d-flex justify-content-center">
                        <div class="card col-3 m-1">
                            <h3 class="card-title"><i class="fa-brands fa-buffer"></i> Assets</h3>
                            <p><?php echo e($vehicles->count()); ?></p>
                        </div>
                        <div class="col-9 row d-flex justify-content-center">
                            <div class="card col-lg-2 col-sm-4 m-1">
                                <div class="card-body">
                                    <i class="fa-solid fa-tractor"></i> Tractors 
                                    <p><?php echo e($vehicles->where('type','Tractor')->count()); ?></p>
                                </div>
                            </div>
                            <div class="card col-lg-2 col-sm-4 m-1">
                                <div class="card-body">
                                    <i class="fa-solid fa-truck"></i> Trucks
                                    <p><?php echo e($vehicles->where('type','Truck')->count()); ?></p>
                                </div>
                            </div>
                            <div class="card col-lg-2 col-sm-4 m-1">
                                <div class="card-body">
                                    <i class="fa-solid fa-car"></i> SUVs
                                    <p><?php echo e($vehicles->where('type','SUV')->count()); ?></p>
                                </div>
                            </div>
                            <div class="card col-lg-2 col-sm-4 m-1">
                                <div class="card-body">
                                    <i class="fa-solid fa-bus"></i> Buses
                                    <p><?php echo e($vehicles->where('type','Bus')->count()); ?></p>
                                </div>
                            </div>
                            <div class="card col-lg-2 col-sm-4 m-1">
                                <div class="card-body">
                                    <i class="fa-solid fa-truck-front"></i> Trailers
                                    <p><?php echo e($vehicles->where('type','Trailer')->count()); ?></p>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="accordion-body" >
                        <div class="row d-flex justify-content-center" >
                            <div class="col-sm-5 p-1 col-lg-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h3 class="card-title">Users</h3>
                                        <div class="pie animate" style="--p:100;--c:darkblue;--b:10px"> <?php echo e($clients->count()); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-5 p-1 col-lg-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h3 class="card-title">Cars</h3>
                                        <div class="pie animate" style="--p:100;--c:orange; --b:10px"><?php echo e($vehicles->count()); ?></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-5 p-1 col-lg-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h3 class="card-title">Purchases</h3> 
                                        <div class="pie animate" style="--p:100;--c:purple;--b:10px">86</div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-5 p-1 col-lg-3">
                                <div class="card">
                                    <div class="card-body">
                                        <h3 class="card-title">Hires</h3>
                                        <div class="pie animate" style="--p:80;--c:lightgreen; --b:10px;">80 </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div id="brands" class="accordion-collapse collapse " aria-labelledby="brands" data-bs-parent="#accordionFlushExample" style="text-align:center ;">
                    
                    <div class="accordion-body" >
                        <div class="row d-flex justify-content-center" >
                            <table class="table">
                                <thead style='text-align:center;'>
                                    <th>#</th>
                                    <th>Model</th>
                                    <th colspan="2">Brand</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?>.</td>
                                        <td style="font-family:Verdana, Geneva, Tahoma, sans-serif"><?php echo e($model->model_name); ?></td>
                                        <td colspan="2">
                                            <?php $__currentLoopData = $brands->where('model_id', $model->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="d-flex justify-content-between">
                                                <div><?php echo e($brand->brand_name); ?></div>
                                                <div><?php echo e($vehicles->where('brand_name',$brand->brand_name)->count()); ?></div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    
                </div>
                <div id="clients" class="accordion-collapse collapse" aria-labelledby="clients" data-bs-parent="#accordionFlushExample">
                    <h2 class="d-flex justify-content-center">Clients</h2>
                    <div class="row d-flex justify-content-center p-2">
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=> $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-success d-flex justify-content-between mb-2">
                                <div><?php echo e($id+1); ?>. </div>
                                <div id="liveToastBtn" type="button"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></div>
                                <div><?php echo e($user->role); ?></div>
                                <div style="text-transform:capitalize ;"><?php echo e($user->country); ?></div>
                                <a href="" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-ellipsis"></i></a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href=" ">Onboard</a></li>
                                </ul>
                            </div>
                            <div>
                                <div id="liveToast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
                                    <div class="toast-header">
                                        <img src="<?php echo e(asset('storage/img/captain.png')); ?>" class="rounded me-2" width=20>
                                        <strong class="me-auto"><?php echo e($user->first_name); ?> </strong>
                                        <small><?php echo e($user->role); ?></small>
                                        <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                                    </div>
                                    <div class="toast-body d-flex justify-content-between">
                                        <div><?php echo e($user->phone); ?></div>
                                        <div><?php echo e($user->email); ?></div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div id="assets" class="accordion-collapse collapse" aria-labelledby="assets" data-bs-parent="#accordionFlushExample">
                    <h2 class="d-flex justify-content-center">Clients</h2>
                    <div class="row d-flex justify-content-center p-2">
                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind=> $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-success d-flex justify-content-between mb-2">
                                <div><?php echo e($ind+1); ?>. </div>
                                <div type="button"><?php echo e($vehicle->license); ?></div>
                                <div><?php echo e($vehicle->type); ?></div>
                                <div><?php echo e($vehicle->color); ?></div>
                                <div><?php echo e($vehicle->brand_name); ?></div>
                                <a href="" type="button"data-bs-toggle="modal" data-bs-target="#detail<?php echo e($vehicle->id); ?>" ><i class="fa-solid fa-ellipsis"></i></a>
                                <div class="modal fade" id="detail<?php echo e($vehicle->id); ?>" tabindex="-1" aria-labelledby="detail<?php echo e($vehicle->id); ?>" aria-hidden="true">
                                    <div class="modal-dialog text-dark">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="detail<?php echo e($vehicle->id); ?>"><?php echo e($vehicle->license); ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                                <div class="modal-body">
                                                    <div>Type : <?php echo e($vehicle->license); ?></div>
                                                    <div>Model: <?php echo e($vehicle->license); ?></div>
                                                    <div>Brand: <?php echo e($vehicle->brand_name); ?></div>
                                                    <div>Color: <?php echo e($vehicle->color); ?></div>
                                                    <div>Chassis: <?php echo e($vehicle->chassis_number); ?></div>
                                                    <div>Engine : <?php echo e($vehicle->engine_number); ?></div>
                                                    <div>Owner : <?php echo e($vehicle->license); ?></div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div id="messages" class="accordion-collapse collapse" aria-labelledby="messages" data-bs-parent="#accordionFlushExample">
                    <h2 class="d-flex justify-content-center">Messages</h2>
                    <div class="row">
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 p-2">
                            <div class="card p-2" style="height:250px ;">
                                <?php if($message->status==0): ?>
                                    <div class="bg-primary p-1"></div>
                                <?php else: ?>
                                    <div class="bg-secondary p-1"></div>
                                <?php endif; ?>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between mb-2">
                                        <div><strong><i><?php echo e($message->name); ?></i></strong></div>
                                        <small><?php echo e($message->phone); ?></small>
                                        <a href="" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fa-solid fa-ellipsis"></i></a>
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                            <?php if($message->status==0): ?>
                                            <li><a class="dropdown-item" href="/read/<?php echo e($message->id); ?>" style="text-decoration:none ;">Mark as read</a></li>
                                            <?php else: ?>
                                            <li><a class="dropdown-item" href="/unread/<?php echo e($message->id); ?>" style="text-decoration:none ;">Mark as unread</a></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <h6 class="card-title" style="font-family:cursive;">Subject: <?php echo e($message->subject); ?></h6>
                                    <p class="card-text" style="font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;"><?php echo e($message->message); ?></p>
                                    <div class="d-flex justify-content-end">
                                        <small><?php echo e(date_format($message->created_at,'F j, Y')); ?></small>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <!--Modals-->
<div class="modal fade" id="model" tabindex="-1" aria-labelledby="model" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="model">Model</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="addModel" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class='form-floating mb-2'>
                        <input type="text" id="m-name" class="form-control" name="model_name" placeholder=" " />
                        <label for="m-name">Model Name</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Add</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="type" tabindex="-1" aria-labelledby="type" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="type">Type</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="addType" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class='form-floating mb-2'>
                        <input type="text" id="m-name" class="form-control" name="type_name" placeholder=" " />
                        <label for="m-name">Vehicle Type</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Add</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="brand" tabindex="-1" aria-labelledby="brand" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="brand">Brand</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="addBrand" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class='form-floating mb-2'>
                        <select name="model_id" class='form-control'id="">
                            <option value="" class='form-control'></option>
                            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($model->id); ?>" class='form-control'><?php echo e($model->model_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label for="m-name">Model Name</label>
                    </div>
                    <div class='form-floating mb-2'>
                        <input type="text" id="m-name" class="form-control" name="brand_name" placeholder=" " />
                        <label for="m-name">Brand Name</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> Add</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php echo e(View::make('footer')); ?><?php /**PATH E:\Websites\aqua_torpedo\resources\views/dashboard.blade.php ENDPATH**/ ?>