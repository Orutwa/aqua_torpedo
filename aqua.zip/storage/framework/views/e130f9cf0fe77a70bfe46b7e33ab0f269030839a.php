<?php echo e(View::make('header',['title'=>'Vehicles'])); ?>

  <div class="container row d-flex justify-content-center m-2" style="min-height:500px; text-transform:capitalize;">
    <?php if($message): ?>
      <h4 class="alert alert-success fade"><?php echo e($message); ?></h4>
    <?php endif; ?>
    <form action="/reg_vehicle" novalidate method="post" class="col-lg-6 card needs-validation">
      <?php echo csrf_field(); ?>
      <div>
        <h3>Vehicle Registration Details</h3>

        <div class='form-floating mb-2'>
          <select class="form-control mb-3 has-validation" name="type_id" required>
          <option value="" class="text-secondary" selected disabled>Select Vehicle Type</option>
          <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <div class="invalid-feedback">This field is required.</div>
        </div>

        <div class='form-floating mb-2'>
          <select class="form-control mb-3 has-validation" name="brand_id"  required>
          <option value="" selected disabled>Select Vehicle Brand</option>
          <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->brand_name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <div class="invalid-feedback">This field is required.</div>
        </div>
        
        <div class='form-floating mb-2'>
          <input type="text" class="form-control mb-3 has-validation" name="chassis_number" required/>
          <label for="">Chassis Number</label>
          <div class="invalid-feedback">This field is required.</div>
        </div>
        <div class='form-floating mb-2'>
          <input type="text" class="form-control mb-3 has-validation" name="engine_number" required/>
          <label for="m-name">Engine Number</label>
          <div class="invalid-feedback">This field is required.</div>
        </div>
        <div class='form-floating mb-2'>
          <input type="text" class="form-control mb-3 has-validation" name="license" required/>
          <label for="m-name">Registration</label>
          <div class="invalid-feedback">This field is required.</div>
        </div>
        <div class='form-floating mb-2'>
          <input type="text" class="form-control mb-3 has-validation" name="color" placeholder="" required/>
          <label for="m-name">Color</label>
          <div class="invalid-feedback">This field is required.</div>
        </div>
        <div class='form-floating mb-2'>
          <input type="number" class="form-control mb-3 has-validation" name="mileage" placeholder="" required/>
          <label for="m-name">Mileage</label>
          <div class="invalid-feedback">This field is required.</div>
        </div>
        <div class="modal-footer">
          <button type='reset' class="btn btn-outline-secondary m-2 has-validation">Clear</button>
          <button type='submit' class="btn btn-outline-success m-2">Register</button>
        </div>
      </div>
    </form>
  </div>
  <script src="<?php echo e(asset('storage/js/form.js')); ?>"></script>
<?php echo e(View::make('footer')); ?><?php /**PATH E:\Websites\aqua_torpedo\resources\views/vehicles.blade.php ENDPATH**/ ?>